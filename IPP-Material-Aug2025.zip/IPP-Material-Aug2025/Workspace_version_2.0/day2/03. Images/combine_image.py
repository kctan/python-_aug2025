from PIL import Image

def combine_images(image1_path, image2_path, output_path):
    # Open the two images
    image1 = Image.open(image1_path)
    image2 = Image.open(image2_path)
    
    # Get dimensions of both images
    width1, height1 = image1.size
    width2, height2 = image2.size
    
    # Create a new image with a width equal to the sum of both widths, and height of the taller image
    combined_width = width1 + width2
    combined_height = max(height1, height2)
    combined_image = Image.new("RGB", (combined_width, combined_height))
    
    # Paste the two images into the new image
    combined_image.paste(image1, (0, 0))
    combined_image.paste(image2, (width1, 0))
    
    # Save the result
    combined_image.save(output_path)
    print(f"Combined image saved to {output_path}")

def combine_images_vertical(image1_path, image2_path, output_path):
    # Open the two images
    image1 = Image.open(image1_path)
    image2 = Image.open(image2_path)
    
    # Get dimensions of both images
    width1, height1 = image1.size
    width2, height2 = image2.size
    
    # Create a new image with a height equal to the sum of both heights, and width of the wider image
    combined_width = max(width1, width2)
    combined_height = height1 + height2
    combined_image = Image.new("RGB", (combined_width, combined_height))
    
    # Paste the two images into the new image
    combined_image.paste(image1, (0, 0))
    combined_image.paste(image2, (0, height1))
    
    # Save the result
    combined_image.save(output_path)
    print(f"Combined image saved to {output_path}")
    
# File paths
image1_path = 'img/clungup.jpg'  # Replace with the path to your first image
image2_path = 'img/maldives1.jpg'  # Replace with the path to your second image
output_path = 'out/combined_image.jpg'  # Replace with the desired output path

# Combine the images
combine_images(image1_path, image2_path, output_path)

combine_images_vertical(image1_path, image2_path, "out/combine_vertical.jpg")